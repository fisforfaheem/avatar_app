Voice Avatar Hub 
================ 
 
Installation Instructions: 
1. Extract all files to a folder of your choice 
2. Run avatar_app.exe to start the application 
 
Note: All files must be kept together in the same folder. 
